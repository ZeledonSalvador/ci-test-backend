import { Controller, Post, Body, Get } from '@nestjs/common';
import { OperationTimesService } from '../services/OperationTimesService';
import { CreateOperationTimeDto } from '../dto/CreateOperationTimeDto';

@Controller('operation-times')
export class OperationTimesController {
  constructor(private readonly service: OperationTimesService) {}

  @Post()
  create(@Body() dto: CreateOperationTimeDto) {
    return this.service.create(dto);
  }

  @Get()
  findAll() {
    return this.service.findAll();
  }
}
