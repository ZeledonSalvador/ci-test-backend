import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { ShipmentsModule } from './modules/shipments/shipments.module';
import { StatusModule } from './modules/status/status.module';
import { BlacklistModule } from './modules/blacklist/blacklist.module';
import { Drivers } from './models/Drivers';
import { PredefinedStatuses } from './models/PredefinedStatuses';
import { Shipments } from './models/Shipments';
import { Status } from './models/Status';
import { MillsModule } from './modules/mills/mills.module';
import { Users } from './models/Users';
import { BotModule } from './modules/bot/bot.module';
import { ShipmentAttachments } from './models/ShipmentAttachments';
import { InvalidatedShipments } from './models/InvalidatedShipments';
import { InvalidatedShipmentsModule } from './modules/invalidated-shipments/invalidated-shipments.module';
import { ShipmentSeals } from './models/ShipmentSeals';
import { QueueModule } from './modules/queue/queue.module';
import { Queue } from './models/Queue';
import { NavModule } from './modules/nav/nav.module';
import { Clients } from './models/Clients';
import { ShipmentLogs } from './models/ShipmentLogs';
import { LogMetadata } from './models/LogMetadata';
import { Vehicles } from './models/Vehicles';
import { PreTransactionsLeveransModule } from './modules/pre-transactions-leverans/pre-transactions-leverans.module';
import { LogsModule } from './modules/logs/logs.module';
import { SysLogs } from './models/SysLogs';
import { LeveransLoggerModule } from './modules/leverans-logger/leverans-logger.module';
import { BlacklistDrivers } from './models/BlacklistDrivers';
import { LeveransLogger } from './models/LeveransLogger';
import { LeveransUserLoginHistory } from './models/LeveransUserLoginHistory';
import { LeveransUsers } from './models/LeveransUsers';
import { TimeModule } from './modules/time/time.module';
import { ControlSystemModule } from './modules/control-system/control-system.module';
import { TransactionLogEntity } from './models/TransactionLogEntity';
import { DataInconsistency } from './models/DataInconsistency';
import { DataInconsistencyModule } from './modules/data-inconsistency/data-inconsistency.module';
import { OperationTime } from './models/OperationTime';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true, // Hace que las variables de entorno estén disponibles en toda la aplicación
    }),
    TypeOrmModule.forRoot({
      type: process.env.DATABASE_TYPE as 'mssql',
      host: process.env.DATABASE_HOST,
      port: parseInt(process.env.DATABASE_PORT, 10),
      username: process.env.DATABASE_USERNAME,
      password: process.env.DATABASE_PASSWORD,
      database: process.env.DATABASE_NAME,
      entities: [
        Users,
        BlacklistDrivers,
        Drivers,
        PredefinedStatuses,
        Shipments,
        Status,
        Vehicles,
        Clients,
        ShipmentAttachments,
        InvalidatedShipments,
        ShipmentSeals,
        Queue,
        ShipmentLogs,
        LogMetadata,
        SysLogs,
        LeveransLogger,
        LeveransUserLoginHistory,
        LeveransUsers,
        TransactionLogEntity,
        DataInconsistency,
        OperationTime    
      ],
      options: {
        encrypt: false,
        trustServerCertificate: true,
      },
      extra: {
        connectionLimit: 15,
      },
      synchronize: false,
      logging: false,
      autoLoadEntities: false,
    }),
    AuthModule,
    UsersModule,
    StatusModule,
    BlacklistModule,
    ShipmentsModule,
    MillsModule,
    BotModule,
    InvalidatedShipmentsModule,
    QueueModule,
    NavModule,
    LogsModule,
    PreTransactionsLeveransModule,
    LeveransLoggerModule,
    TimeModule,
    ControlSystemModule,
    DataInconsistencyModule,
    OperationTime   
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule { }