import { IsNotEmpty, IsOptional, IsString, IsNumber } from 'class-validator';

export class CreateOperationTimeDto {
  @IsNumber()
  transactionId: number;

  @IsString()
  @IsNotEmpty()
  operationType: string;

  @IsString()
  @IsNotEmpty()
  duration: string;

  @IsString()
  @IsOptional()
  comment?: string;

  @IsString()
  @IsNotEmpty()
  truckType: string;
}
