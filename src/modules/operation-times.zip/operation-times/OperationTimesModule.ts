import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OperationTime } from 'src/models/OperationTime';
import { OperationTimesService } from './services/OperationTimesService';
import { OperationTimesController } from './controllers/OperationTimesController';

@Module({
  imports: [TypeOrmModule.forFeature([OperationTime])],
  controllers: [OperationTimesController],
  providers: [OperationTimesService],
})
export class OperationTimesModule {}
