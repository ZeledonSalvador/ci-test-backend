interface ApiResponseNavCreate {
    message: string;
    logs: any[];
    newRecord: NavRecord;
}