export interface IRoleInfo {
  id: number;
  description: string;
}