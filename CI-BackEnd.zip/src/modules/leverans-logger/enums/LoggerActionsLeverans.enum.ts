export enum LoggerActionLeverans {
    CREATE = 'CREATE',
    UPDATE = 'UPDATE',
    DELETE = 'DELETE',
    VIEW = 'VIEW',
    OTHER = 'OTHER',
    UPDATE_STATUS = "UPDATE_STATUS"
}
