export enum PenaltyType {
  NO_APLICADO = 'No aplicado',
  TEMPORAL = 'Temporal',
  PERMANENTE = 'Permanente',
  FINALIZADO = 'Finalizado'
}