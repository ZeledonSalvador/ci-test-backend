export enum BlacklistStatus {
  INITIAL = 0,
  REPORT_APPLIED = 1,
  PENALTY_APPLIED = 2,
  LIBERATION = 3
}