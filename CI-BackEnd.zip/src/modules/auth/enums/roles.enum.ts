export enum Role {
    CLIENT = 'cliente',
    BOT = 'bot',
    ADMIN = 'admin',
}