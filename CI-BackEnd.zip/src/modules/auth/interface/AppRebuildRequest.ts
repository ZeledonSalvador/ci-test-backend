export default interface AppRebuildRequest extends Request {
    isClient?: boolean;
}