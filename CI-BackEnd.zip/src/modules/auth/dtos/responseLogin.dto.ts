export class resLogin {
    access_token: string;
}