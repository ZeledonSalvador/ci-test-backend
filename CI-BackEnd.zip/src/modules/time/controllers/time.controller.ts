import { Controller } from '@nestjs/common';

@Controller('time')
export class TimeController {}
