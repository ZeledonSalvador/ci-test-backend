import { Controller } from '@nestjs/common';

@Controller('logs-shipments')
export class LogsShipmentsController {}
