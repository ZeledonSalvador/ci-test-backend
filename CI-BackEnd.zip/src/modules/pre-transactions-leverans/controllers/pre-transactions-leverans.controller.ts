import { Controller } from '@nestjs/common';

@Controller('pre-transactions-leverans')
export class PreTransactionsLeveransController {}
